/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

	//Inclus�o das Biliotecas relacionadas ao Display OLED

		#include "stm32f4xx.h"
		#include "fonts.h"
		#include "ssd1306.h"
		#include "test.h"
		#include <string.h>
		#include <stdio.h>
		#define M_PI 3.14159265358979323846

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

osThreadId HorarioHandle;
osThreadId ControleHandle;
osThreadId MudHorarioHandle;
osThreadId HoraAnimadaHandle;
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USART1_UART_Init(void);
void StartDefaultTask(void const * argument);
void StartTask02(void const * argument);
void StartTask03(void const * argument);
void StartTask04(void const * argument);

/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

	// Cria��o das vari�veis para controle de hora, n�mero e resetagem de tela

		int segundos = 0; // Quantidade de segundos
		int horas = 0; // Quantidade de minutos
		int minutos = 0; // Quantidade de horas
		
		char Time[11]; // Char que armazena informa��o de hora
		
		int TelaAtual = 0; // Vari�vel de sele��o de telas
		int reset = 1; // Vari�vel que sinaliza o reset das telas
		
		float Angulo = 7.5; // angulo entre horas do dia em um semi circulo de 180�
		float Raio = 45; // Raio do circulo central da tela de anima��o
		
		int X1; // Posi��o X atual do circulo secundario na tela de anima��o
		int Y1; // Posi��o Y atual do circulo secundario na tela de anima��o
		
		int X2; // Posi��o X anterior do circulo secundario na tela de anima��o
		int Y2; // Posi��o Y anterior do circulo secundario na tela de anima��o
		
		int ValoresX[24] = {19, 19, 21, 22, 25, 28, 32, 37, 42, 47, 52, 58, 64, 70, 76, 81, 87, 91, 96, 100, 103, 106, 107, 109}; // Posi��o X do circulo secund�rio correspondentes a cada hora do dia
		int ValoresY[24] = {64, 58, 52, 47, 42, 37, 32, 28, 25, 22, 21, 19, 19, 19, 21, 22, 25, 28, 32, 37, 42, 47, 52, 64}; // Posi��es Y do circulo secund�rio correspondentes a cada hora do dia
			
		int iniciar = 0; // Controle da comunica��o handshaking
			
		char mestre[16] = "AlienEncontrado\n"; // Informa��o transmitida via handshaking
		char servo[6]; // Informa��o recebida via handshaking
	
		
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_USART2_UART_Init();
  MX_USART3_UART_Init();
  MX_USART1_UART_Init();
	
  /* USER CODE BEGIN 2 */
	
		// Inicializa��o da Tela OLED
	
			SSD1306_Init();
			SSD1306_Clear();
			
		// Inicio da comunica��o Handshaking
		
			// Caso a comunica��o n�o for estabelecida, se inicia o loop de comunica��o
					
				while (iniciar == 0) {	
					
					// Transmiss�o de informa��o do dispositivo mestre para detec��o pelo dispositivo servo
					
					HAL_UART_Transmit(&huart1, (uint8_t*)mestre, 16, 1000);
					
					// Recep��o de informa��o do dispositivo servo para detec��o pelo dispositivo mestre
					
					HAL_UART_Receive(&huart1, (uint8_t*)&servo, 6, 1000);		
							
					// Caso a informa��o do dispositivo servo for detectada corretamente, a comunica��o ir� se encerrar
					
						if (strncmp(servo, "Alien", 5) == 0) {
						
							iniciar = 1;
							HAL_Delay(500);
						
						}
					
					// Escrita da tela enquanto n�o se estabelece comunica��o
					
						SSD1306_GotoXY(16, 16); // Posicionamento do Cursor da Tela
						SSD1306_Puts("Iniciando", &Font_11x18, 1); // Escrita da palavra "Iniciando" na tela
						SSD1306_GotoXY(10, 35); // Posicionamento do Cursor da Tela
						SSD1306_Puts("Omnitrix...", &Font_11x18, 1); // Escrita da palavra "Omnitrix..." na tela
					
						SSD1306_UpdateScreen(); // Atualiza��o da tela para exibi��o da escrita
						
						HAL_Delay(500); // Delay de 0.5 s
						
						SSD1306_Clear(); // Limpeza da Tela 	
					
				}
				
				// Exibi��o de tela sinalizando comunica��o bem sucedida
				
					SSD1306_Clear(); // Limpeza da Tela 	
					
					SSD1306_GotoXY(20, 20); // Posicionamento do Cursor da Tela
					SSD1306_Puts("Omnitrix", &Font_11x18, 1); // Escrita da palavra "Omnitrix" na tela
					SSD1306_GotoXY(20, 40); // Posicionamento do Cursor da Tela
					SSD1306_Puts("Iniciado", &Font_11x18, 1); // Escrita da palavra "Iniciado" na tela
					
					SSD1306_UpdateScreen(); // Atualiza��o da tela para exibi��o da escrita
					
					HAL_Delay(1000); // Delay de 1 s
					
					SSD1306_Clear(); // Limpeza da Tela 	
			
		// Final da Comunica��o Handshaking

  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of Horario */
  osThreadDef(Horario, StartDefaultTask, osPriorityRealtime, 0, 128);
  HorarioHandle = osThreadCreate(osThread(Horario), NULL);

  /* definition and creation of Controle */
  osThreadDef(Controle, StartTask02, osPriorityNormal, 0, 128);
  ControleHandle = osThreadCreate(osThread(Controle), NULL);

  /* definition and creation of MudHorario */
  osThreadDef(MudHorario, StartTask03, osPriorityNormal, 0, 128);
  MudHorarioHandle = osThreadCreate(osThread(MudHorario), NULL);

  /* definition and creation of HoraAnimada */
  osThreadDef(HoraAnimada, StartTask04, osPriorityNormal, 0, 128);
  HoraAnimadaHandle = osThreadCreate(osThread(HoraAnimada), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 9600;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 38400;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PB10 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PA8 PA9 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartDefaultTask */
/**
  * @brief  Function implementing the Horario thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void const * argument)
{
  /* USER CODE BEGIN 5 */
  /* Infinite loop */
	
  for(;;)
  {
		
		// Se a Tela Atual for a de rel�gio digital ou ilustrativo, existe a contagem das horas
		
			if (TelaAtual == 0 || TelaAtual == 1) {
				
				// A cada in�cio de ciclo, um segundo � contado
				
					segundos++;
				
				// Caso se passem 60 segundos, a vari�vel segundo � resetada, e � acrescentada uma unidade aos minutos
				
					if (segundos == 60) {
					
						segundos = 0;
						minutos++;
						
					}

				// Caso se passem 60 minutos, a vari�vel minutos � resetada, e � acrescentada uma unidade �s horas
				
					if (minutos == 60) {
					
						minutos = 0;
						horas++;
					
					}
				
				// Caso se passem 24 horas, a vari�vel horas � resetada		
				
					if (horas == 24) {
					
						horas = 0;
					
					}
					
					// Gera��o de String que possui horas e minutos
					
						// String com horas com digitos �nicos
					
							if (horas < 10) {
								
								// String com minutos com digitos �nicos
							
									if (minutos < 10) {
									
										sprintf(Time, "0%1i : 0%1i   \n", horas, minutos);
									
									}
								
								// String com minutos com digitos duplos
								
									else {
									
										sprintf(Time, "0%1i : %2i   \n", horas, minutos);
									
									}
							
							}
						
						// String com horas com digitos duplos
						
							else {
								
								// String com minutos com digitos �nicos
							
									if (minutos < 10) {
									
										sprintf(Time, "%2i : 0%1i   \n", horas, minutos);
									
									}
								
								// String com minutos com digitos duplos
								
									else {
									
										sprintf(Time, "%2i : %2i   \n", horas, minutos);
									
									}
							
							}
					
					// Transmiss�o da string de hor�rio via Bluetooth
					
						HAL_UART_Transmit(&huart1, (uint8_t*)Time, 11, 100);	
					
				// Caso a tela exibida seja a de rel�gio digital, o tempo � exibido na tela	
					
					if (TelaAtual == 0) {
						
						// Caso a tela seja selecionada, existe uma limpeza �nica da tela OLED
						
						if (reset == 1) {
							
								SSD1306_Clear();
								reset = 0;
							
						}						
						
						// Escrita da Tela do rel�gio digital
						
							SSD1306_GotoXY(27, 0); // Posi��o do Cursor de escrita
							SSD1306_Puts("Relogio", &Font_11x18, 1); // Escrita da palavra "Hor�rio" na posi��o
							SSD1306_GotoXY(23, 35); // Posi��o do Cursor de escrita
							SSD1306_Puts(Time, &Font_11x18, 1); // Escrita da palavra "Hor�rio" na posi��o
							SSD1306_UpdateScreen(); // Atualiza��o da tela para exibi��o da escrita
						
				}
					
			}
			
			// Delay de 1 segundo entre ciclos
				
				osDelay(1000);
			
		}
		
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartTask02 */
/**
* @brief Function implementing the Controle thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask02 */
void StartTask02(void const * argument)
{
  /* USER CODE BEGIN StartTask02 */
  /* Infinite loop */
	
  for(;;)
  {
		
		// Se o bot�o de troca de tela for pressionado, a tela subsequente � acionada
		
			if (HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_10) == 1) {
						
				HAL_Delay(1000); // Delay de 1 s
				TelaAtual++; // Pr�xima Tela � Selecionada
				reset = 1; // Requerimento de resetagem da tela
				
			}
			
		// Se as telas acabam na sequ�ncia, se � reposicionado para a primeira tela da sequ�ncia
		
			if (TelaAtual == 3) {
			
				TelaAtual = 0;
			
			}
			
		// Delay de 1 segundos entre Ciclos
		
    osDelay(1000);
		
  }
  /* USER CODE END StartTask02 */
}

/* USER CODE BEGIN Header_StartTask03 */
/**
* @brief Function implementing the MudTela thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask03 */
void StartTask03(void const * argument)
{
  /* USER CODE BEGIN StartTask03 */
	
  /* Infinite loop */
	
  for(;;)
  {
		
		// S� � poss�vel ajustar o hor�rio do rel�gio quando se est� nessa tela
		
			if (TelaAtual == 2) {
				
				segundos = 0;
				
				// Se o bot�o de horas for pressionado, � acrescido uma unidade � unidade de tempo
				
					if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_9) == 1) {
					
						horas++;
						
						// Se extrapolar o n�mero de horas por dia, a unidade de tempo reinicia em 0
						
							if (horas == 24) {
							
								horas = 0;
							
							}
					
					}
				
				// Se o bot�o de minutos for pressionado, � acrescido uma unidade � unidade de tempo
				
					if(HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8) == 1) {
					
						minutos++;
						
						// Se extrapolar o n�mero de minutos por hora, a unidade de tempo reinicia em 0
						
							if (minutos == 60) {
							
								minutos = 0;
							
							}
					
					}
				
				// Caso a tela seja selecionada, existe uma limpeza �nica da tela OLED
			
					if (reset == 1) {
					
						SSD1306_Clear();
						reset = 0;
					
					}
					
				// Escrita da Tela do rel�gio digital

						SSD1306_GotoXY(30, 0); // Posi��o do Cursor de escrita
						SSD1306_Puts("Ajuste", &Font_11x18, 1); // Escrita da palavra "Hor�rio" na posi��o
						SSD1306_GotoXY(20, 35); // Posi��o do Cursor de escrita
						sprintf(Time, "%2i  : %2i", horas, minutos); // Convers�o de minutos e horas em string unica
						SSD1306_Puts(Time, &Font_11x18, 1); // Escrita da palavra "Hor�rio" na posi��o
						SSD1306_UpdateScreen(); // Atualiza��o da tela para exibi��o da escrita
			
			}
			
		// Delay de 0.25 s entre ciclos
		
			osDelay(250);
		
	}
		
  /* USER CODE END StartTask03 */
}

/* USER CODE BEGIN Header_StartTask04 */
/**
* @brief Function implementing the HoraAnimada thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_StartTask04 */
void StartTask04(void const * argument)
{
  /* USER CODE BEGIN StartTask04 */
  /* Infinite loop */
	
  for(;;)
  {
		
		// S� � poss�vel visualizar a anima��o caso a mesma esteja selecionada
		
			if (TelaAtual == 1) {
				
				// Sele��o dos par�metros X e Y do item anterior da lista, que, no caso do in�cio da lista, � o final da mesma
				
					if (horas == 0) {
					
						X2 = ValoresX[23];
						
						Y2 = ValoresY[23];
					
					}
					
				// Sele��o dos par�metros X e Y do item anterior da lista
				
					else {
					
						X2 = ValoresX[horas - 1];
						
						Y2 = ValoresY[horas - 1];
					
				}			
					
				// Deletagem da imagem criada na coordenada anterior
				
					SSD1306_DrawFilledCircle(X2, Y2, 4, 0);	
				
				// Cria��o do Circulo Principal
				
					SSD1306_DrawCircle(64, 64, 45, 1);
				
				// Caso a tela seja selecionada, existe uma limpeza �nica da tela OLED
			
					if(reset == 1) {
					
						SSD1306_Clear();
						reset = 0;
					
					}
					
				// Sele��o dos par�metros X e Y do item atual 
				
					X1 = ValoresX[horas];
				
					Y1 = ValoresY[horas];
					
				// Desenho do Sol na posi��o atual de horas
				
					SSD1306_DrawFilledCircle(X1, Y1, 4, 1);
					
				// Atualiza��o da Tela para exibi��o da escrita
				
				SSD1306_UpdateScreen();
			
			}
			
			// Delay de 0.1s entre ciclos
			
				osDelay(100);
			
  }
  /* USER CODE END StartTask04 */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
